# Courier Finder

A free, static website that suggests a likely parcel carrier from common tracking-number patterns. It does not use paid APIs, does not send tracking numbers to a server, and does not retrieve live delivery status.

## Run locally

1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Double-click `index.html` to open it in a modern browser.
3. Enter a tracking number and choose **Find courier**.

If your browser restricts local files, run a local server instead:
- With Python installed, open a terminal in this folder and run `python -m http.server 8000`
- Visit `http://localhost:8000`

## Publish free with GitHub Pages

1. Sign in or create a free account at https://github.com.
2. Click **New repository**. Give it a name such as `courier-finder`. For the easiest setup, make it **Public**.
3. Upload `index.html`, `style.css`, and `script.js` to the repository root. You can use **Add file → Upload files**, then commit the changes.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Choose branch `main` and folder `/(root)`, then save.
7. Wait a minute or two. GitHub Pages will show the published URL, usually:
   `https://YOUR-USERNAME.github.io/courier-finder/`

## Important limitations

- This is a heuristic pattern matcher. Tracking-number formats overlap and change, so it may suggest the wrong carrier or no carrier.
- The displayed confidence score is a hand-tuned format-match score, not a statistically calibrated probability.
- It cannot prove a parcel exists or show live delivery status. Tracking links take you to the carrier's tracking page.
- The multi-carrier fallback opens 17TRACK in a new tab; that third-party service has its own terms and privacy policy.
- The website uses Google Fonts from a CDN for typography. To make it fully offline, remove the `@import` line at the top of `style.css`; system fonts will be used instead.
- Check carrier tracking URLs and number formats periodically before relying on them.
